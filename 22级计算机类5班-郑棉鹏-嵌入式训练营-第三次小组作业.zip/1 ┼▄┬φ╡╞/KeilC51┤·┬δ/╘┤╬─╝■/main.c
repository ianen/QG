#include <REGX52.H>
#include <INTRINS.H>

void Delay1ms(unsigned int xms)		//@12.000MHz
{
	unsigned char i, j;
	while(xms)
	{
		i = 2;
		j = 239;
		do
		{
			while (--j);
		} while (--i);
		xms--;
	}
}

void main()
{
	while(1)
	{
		P2=0xFE;
		Delay1ms(500);
		P2=0xFD;
		Delay1ms(500);
		P2=0xFB;
		Delay1ms(500);
		P2=0xF7;
		Delay1ms(500);
		P2=0xEF;
		Delay1ms(500);
		P2=0xDE;
		Delay1ms(500);
		P2=0xBE;
		Delay1ms(500);
		P2=0x7E;
		Delay1ms(500);
	}
}