#ifndef __NIXIE_H__
#define __NIXIE_H__

extern unsigned char NixieTable[];
void Nixie(unsigned char Location,Number);

#endif