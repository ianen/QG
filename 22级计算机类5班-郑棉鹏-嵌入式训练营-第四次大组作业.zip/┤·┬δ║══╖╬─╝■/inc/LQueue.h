/***************************************************************************************
 *    File Name                :    LQueue.h
 *    CopyRight                :
 *
 *    SYSTEM                    :   Mac OS
 *    Create Data                :    2020.4.2
 *    Author/Corportation        :   Chuan Shi
 *
 *
 *--------------------------------Revision History--------------------------------------
 *    No    version        Data            Revised By            Item            Description
 *
 *
 ***************************************************************************************/

/**************************************************************
 *    Multi-Include-Prevent Section
 **************************************************************/
#ifndef LQUEUE_H_INCLUDED
#define LQUEUE_H_INCLUDED
#define TRUE 1
#define FALSE 0

#include "binary_sort_tree.h"

/**************************************************************
 *    Struct Define Section
 **************************************************************/
//??????��?

typedef struct qNode
{
  NodePtr data;         //?????????
  struct qNode *next; //??????????????
} QNode;

typedef struct Lqueue
{
  QNode *front; //???
  QNode *rear;  //??��
  int length;   //???��???
} LQueue;

/**************************************************************
 *    Prototype Declare Section
 **************************************************************/

/**
 *  @name        : void InitLQueue(LQueue *Q)
 *    @description : ?????????
 *    @param         Q ???????Q
 *  @notice      : None
 */
void InitLQueue(LQueue **Q);

/**
 *  @name        : void DestoryLQueue(LQueue *Q)
 *    @description : ???????
 *    @param         Q ???????Q
 *  @notice      : None
 */
void DestoryLQueue(LQueue *Q);

/**
 *  @name        : Status IsEmptyLQueue(const LQueue *Q)
 *    @description : ????????????
 *    @param         Q ???????Q
 *    @return         : ??-TRUE; ��??-FALSE
 *  @notice      : None
 */
BStatus IsEmptyLQueue(const LQueue *Q);

/**
 *  @name        : Status GetHeadLQueue(LQueue *Q, void *e)
 *    @description : ????????
 *    @param         Q e ???????Q,???????????e
 *    @return         : ???-TRUE; ???-FALSE
 *  @notice      : ????????
 */
NodePtr GetHeadLQueue(LQueue *Q);

/**
 *  @name        : int LengthLQueue(LQueue *Q)
 *    @description : ??????��???
 *    @param         Q ???????Q
 *    @return         : ???-TRUE; ???-FALSE
 *  @notice      : None
 */
int LengthLQueue(LQueue *Q);

/**
 *  @name        : Status EnLQueue(LQueue *Q, void *data)
 *    @description : ??????
 *    @param         Q ???????Q,??????????data
 *    @return         : ???-TRUE; ???-FALSE
 *  @notice      : ??????????
 */
BStatus EnLQueue(LQueue *Q, NodePtr data);

/**
 *  @name        : Status DeLQueue(LQueue *Q)
 *    @description : ???????
 *    @param         Q ???????Q
 *    @return         : ???-TRUE; ???-FALSE
 *  @notice      : None
 */
BStatus DeLQueue(LQueue *Q);

/**
 *  @name        : void ClearLQueue(AQueue *Q)
 *    @description : ??????
 *    @param         Q ???????Q
 *  @notice      : None
 */
void ClearLQueue(LQueue *Q);

/**
 *  @name        : Status TraverseLQueue(const LQueue *Q, void (*foo)(void *q))
 *    @description : ????????????
 *    @param         Q ???????Q?????????????foo
 *    @return         : None
 *  @notice      : None
 */
BStatus TraverseLQueue(const LQueue *Q, void (*foo)(NodePtr q));

/**
 *  @name        : void LPrint(void *q)
 *    @description : ????????
 *    @param         q ???q

 *  @notice      : None
 */
void LPrint(NodePtr q);

/**************************************************************
 *    End-Multi-Include-Prevent Section
 **************************************************************/
#endif // LQUEUE_H_INCLUDED
