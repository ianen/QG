#ifndef STACK_H_INCLUDED
#define STACK_H_INCLUDED

#define MAX_SIZE 1000

#include "binary_sort_tree.h"

typedef struct StackNode
{
	NodePtr node;
	struct StackNode *next;
} StackNode, *LinkStackPtr;

typedef struct LinkStack
{
	LinkStackPtr top;
	int count;
} LinkStack;

//��ջ
BStatus initLStack(LinkStack **s);				  //��ʼ��ջ
BStatus isEmptyLStack(LinkStack *s);				  //�ж�ջ�Ƿ�Ϊ��
BStatus getTopLStack(LinkStack *s, NodePtr *node); //�õ�ջ��Ԫ��
BStatus clearLStack(LinkStack *s);				  //����?
BStatus destroyLStack(LinkStack **s);			  //����ջ
BStatus LStackLength(LinkStack *s, int *length);	  //���ջ����?
BStatus pushLStack(LinkStack *s, NodePtr node);	  //��ջ
BStatus popLStack(LinkStack *s, NodePtr *node);	  //��ջ

#endif
