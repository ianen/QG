#include <stdlib.h>
#include "LinkStack.h"

//��ʼ��ջ
BStatus initLStack(LinkStack **s)
{
	(*s) = (LinkStack *)malloc(sizeof(LinkStack));
	if (!s)
		return failed;

	(*s)->top = NULL;
	(*s)->count = 0;
	return succeed;
}

//�ж�ջ�Ƿ�Ϊ��
BStatus isEmptyLStack(LinkStack *s)
{
	if (s->count == 0)
		return succeed;
	else
		return failed;
}

//�õ�ջ��Ԫ��
BStatus getTopLStack(LinkStack *s, NodePtr *node)
{
	if (s->count == 0)
		return failed;

	*node = s->top->node;
	return succeed;
}

//���ջ
BStatus clearLStack(LinkStack *s)
{
	LinkStackPtr S;
	while (s->count)
	{
		S = s->top;
		s->top = s->top->next;
		free(S);
		s->count--;
	}
	return succeed;
}

//����ջ
BStatus destroyLStack(LinkStack **s)
{
	LinkStack *p = *s;
	clearLStack(p);
	free(p);
	*s = NULL;
	return succeed;
}

//���ջ����
BStatus LStackLength(LinkStack *s, int *length)
{
	*length = s->count;
	return succeed;
}

//��ջ
BStatus pushLStack(LinkStack *s, NodePtr node)
{
	if (s->count >= MAX_SIZE)
	{
		return failed;
	}

	LinkStackPtr S = (LinkStackPtr)malloc(sizeof(StackNode));
	S->node = node;
	S->next = s->top;
	s->top = S;
	s->count++;
	return succeed;
}

//��ջ
BStatus popLStack(LinkStack *s, NodePtr *node)
{
	if (s->count == 0)
		return failed;

	LinkStackPtr p;
	*node = s->top->node;
	p = s->top;
	s->top = s->top->next;
	free(p);
	s->count--;
	return succeed;
}
