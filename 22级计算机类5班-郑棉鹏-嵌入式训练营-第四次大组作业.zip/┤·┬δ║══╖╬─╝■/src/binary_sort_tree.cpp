#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include "binary_sort_tree.h"
#include "LinkStack.h"
#include "LQueue.h"

void NodeAdd(NodePtr node)
{
    node->value++;
}

/**
 * BST initialize
 * @param BinarySortTreePtr BST
 * @return is complete
 */
BStatus BST_init(BinarySortTreePtr BST)
{
    // BST为NULL时
    if (!BST)
        return failed;

    //初始化root
    BST->root = NULL;
    return succeed;
}

/**
 * BST insert
 * @param BinarySortTreePtr BST
 * @param ElemType value to insert
 * @return is successful
 */
BStatus BST_insert(BinarySortTreePtr BST, ElemType newElem)
{
    // BST为NULL时
    if (!BST)
        return failed;

    // 创建一个新节点
    NodePtr newNode = (NodePtr)malloc(sizeof(Node));
    if (!newNode)
        return failed;
    newNode->value = newElem;
    newNode->left = NULL;
    newNode->right = NULL;

    // BST为空时，将节点插入到 BST 中
    if (BST->root == NULL)
    {
        BST->root = newNode; // 如果 BST 为空，则将新节点作为根节点
        return succeed;      // 返回插入成功
    }

    // 遍历BST
    NodePtr curNode = BST->root;
    NodePtr parentNode = NULL;
    while (curNode)
    {
        parentNode = curNode;
        if (newElem < curNode->value)
            curNode = curNode->left; // 在左子树中查找插入位置
        else if (newElem > curNode->value)
            curNode = curNode->right; // 在右子树中查找插入位置
        else {
            free(newNode);
            return failed;
        }
    }

    // 插入新节点
    if (newElem < parentNode->value)
        parentNode->left = newNode;
    else
        parentNode->right = newNode;

    return succeed;
}

/**
 * BST delete
 * @param BinarySortTreePtr BST
 * @param ElemType the value for Node which will be deleted
 * @return is successful
 */
BStatus BST_delete(BinarySortTreePtr BST, ElemType deleteElem)
{
    // BST为空时，直接返回
    if (!BST || !BST->root)
        return failed;

    //寻找要删除的节点
    NodePtr curNode = BST->root;
    NodePtr parentNode = NULL;
    while (curNode != NULL && curNode->value != deleteElem)
    {
        parentNode = curNode;
        if (deleteElem < curNode->value)
            curNode = curNode->left; // 在左子树中查找删除位置
        else
            curNode = curNode->right; // 在右子树中查找删除位置
    }
    if (curNode == NULL) //没有要删除的节点
        return failed;

    //如果要删除的节点有两个子节点
    if (curNode->left != NULL && curNode->right != NULL)
    {
        NodePtr minNode = curNode->right;
        parentNode = curNode;
        while (minNode->left != NULL) //将待删节点右子树中最小的节点与之代替，再来删除节点（方便删除）
        {
            parentNode = minNode;
            minNode = minNode->left;
        }
        curNode->value = minNode->value;
        curNode = minNode; // 待删除节点改为后继节点，方便后续操作
    }

    //如果待删除节点没有子节点或者只有一个子节点
    NodePtr childNode;
    if (curNode->left != NULL)
        childNode = curNode->left;
    else if (curNode->right != NULL)
        childNode = curNode->right;
    else
        childNode = NULL;

    //删除节点
    if (parentNode == NULL)
        BST->root = childNode; //删除的是根节点
    else if (curNode == parentNode->left)
        parentNode->left = childNode;
    else
        parentNode->right = childNode;

    free(curNode);
    return succeed;
}

/**
 * BST search
 * @param BinarySortTreePtr BST
 * @param ElemType the value to search
 * @return is exist
 */
BStatus BST_search(BinarySortTreePtr BST, ElemType searchedElem)
{
    // BST为空时，直接返回
    if (!BST || !BST->root)
        return failed;

    NodePtr curNode = BST->root;
    while (curNode)
    {
        if (searchedElem == curNode->value) //找到目标节点
            return true;
        else if (searchedElem < curNode->value) // 目标值比当前节点值小，往左子树查找
            curNode = curNode->left;
        else if (searchedElem > curNode->value) // 目标值比当前节点值大，往右子树查找
            curNode = curNode->right;
    }

    // 遍历完整棵树仍未找到目标值
    return false;
}

/**
 * BST preorder traversal without recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
BStatus BST_preorderI(BinarySortTreePtr BST, void (*visit)(NodePtr))
{
    // BST为空时，直接返回
    if (!BST || !BST->root)
        return failed;

    // 创建一个栈，保存要遍历的节点
    NodePtr stack[MAX_SIZE];
    int top = -1;

    // 将根节点压入栈
    stack[++top] = BST->root;

    while (top >= 0)
    {
        // 弹出栈顶元素
        NodePtr curNode = stack[top--];

        // 访问当前节点
        visit(curNode);

        // 将右子节点入栈
        if (curNode->right)
            stack[++top] = curNode->right;

        // 将左子节点入栈
        if (curNode->left)
            stack[++top] = curNode->left;
    }

    return succeed;
}

/**
 * 前序遍历二叉树，使用递归方式实现
 * @param NodePtr node 二叉树节点
 * @param void (*visit)(NodePtr) 回调函数，用于访问节点
 * @return void
 */
void preorderTraverse(NodePtr node, void (*visit)(NodePtr))
{
    if (node == NULL)
        return;

    visit(node);                          //对节点进行处理
    preorderTraverse(node->left, visit);  //递归到左子节点
    preorderTraverse(node->right, visit); //递归到右子节点
}

/**
 * BST preorder traversal with recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
BStatus BST_preorderR(BinarySortTreePtr BST, void (*visit)(NodePtr))
{
    // BST为NULL时
    if (!BST || !BST->root)
        return failed;

    preorderTraverse(BST->root, visit); //对二叉树进行前序递归
    return succeed;
}

/**
 * BST inorder traversal without recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
BStatus BST_inorderI(BinarySortTreePtr BST, void (*visit)(NodePtr))
{
    // BST为空时，直接返回
    if (!BST || !BST->root)
        return failed;

    // 创建一个栈，用于存储访问过的节点
    LinkStack *stack;
    if (!initLStack(&stack))
        return failed;

    // 从根节点开始遍历
    NodePtr curNode = BST->root;
    while (curNode || !isEmptyLStack(stack))
    {
        // 将左子树节点入栈
        while (curNode)
        {
            pushLStack(stack, curNode);
            curNode = curNode->left;
        }

        // 访问栈顶节点，然后将右子树节点入栈
        if (!isEmptyLStack(stack))
        {
            popLStack(stack, &curNode);
            visit(curNode);
            curNode = curNode->right;
        }
    }

    destroyLStack(&stack);
    return succeed;
}

/**
 * 中序遍历二叉树，使用递归方式实现
 * @param NodePtr node 二叉树节点
 * @param void (*visit)(NodePtr) 回调函数，用于访问节点
 * @return void
 */
void inorderTraverse(NodePtr node, void (*visit)(NodePtr))
{
    if (node == NULL)
        return;

    inorderTraverse(node->left, visit);
    visit(node); // 访问节点
    inorderTraverse(node->right, visit);
}

/**
 * BST inorder traversal with recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
BStatus BST_inorderR(BinarySortTreePtr BST, void (*visit)(NodePtr))
{
    // BST为NULL时
    if (!BST || !BST->root)
        return failed;

    inorderTraverse(BST->root, visit); //对二叉树进行中序递归
    return succeed;
}

/**
 * BST preorder traversal without recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
BStatus BST_postorderI(BinarySortTreePtr BST, void (*visit)(NodePtr))
{
    // BST为空时，直接返回
    if (!BST || !BST->root)
        return failed;

    // 创建两个栈，用于存储访问过的节点
    LinkStack *stack1, *stack2;
    if (!initLStack(&stack1) || !initLStack(&stack2))
        return failed;

    NodePtr curNode = BST->root;

    // 用后序将节点存入待遍历栈中
    pushLStack(stack1, curNode);
    while (!isEmptyLStack(stack1))
    {
        popLStack(stack1, &curNode);
        pushLStack(stack2, curNode);

        if (curNode->left)
            pushLStack(stack1, curNode->left);
        if (curNode->right)
            pushLStack(stack1, curNode->right);
    }

    //遍历
    while (!isEmptyLStack(stack2))
    {
        popLStack(stack2, &curNode);
        visit(curNode);
    }

    destroyLStack(&stack1);
    destroyLStack(&stack2);
    return succeed;
}

/**
 * 后序遍历二叉树，使用递归方式实现
 * @param NodePtr node 二叉树节点
 * @param void (*visit)(NodePtr) 回调函数，用于访问节点
 * @return void
 */
void posorderTraverse(NodePtr node, void (*visit)(NodePtr))
{
    if (node == NULL)
        return;

    posorderTraverse(node->left, visit);
    posorderTraverse(node->right, visit);
    visit(node); // 访问节点
}

/**
 * BST postorder traversal with recursion
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
BStatus BST_postorderR(BinarySortTreePtr BST, void (*visit)(NodePtr))
{
    // BST为空时，直接返回
    if (!BST || !BST->root)
        return failed;

    posorderTraverse(BST->root, visit);
    return succeed;
}

/**
 * BST level order traversal
 * @param BinarySortTreePtr BST
 * @param (*visit) callback
 * @return is successful
 */
BStatus BST_levelOrder(BinarySortTreePtr BST, void (*visit)(NodePtr))
{
    // BST为空时，直接返回
    if (!BST || !BST->root)
        return failed;

    //创建一个队列
    LQueue *queue;
    InitLQueue(&queue);

    NodePtr curNode = NULL;
    EnLQueue(queue, BST->root); // 将根节点入队

    while (!IsEmptyLQueue(queue))
    {
        curNode = GetHeadLQueue(queue); //出队头的节点
        DeLQueue(queue);
        visit(curNode);

        if (curNode->left)
            EnLQueue(queue, curNode->left); //左子节点入队
        if (curNode->right)
            EnLQueue(queue, curNode->right); //右子节点入队
    }

    DestoryLQueue(queue);
    return succeed;
}
