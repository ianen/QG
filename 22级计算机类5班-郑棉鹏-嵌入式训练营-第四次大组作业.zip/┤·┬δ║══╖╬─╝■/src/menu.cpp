#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include "binary_sort_tree.h"
#include "menu.h"
   
// ���ư�ť
void DrawButton(Button* btn) {
    setbkcolor(btn->color);
    setfillcolor(btn->color);
    settextcolor(WHITE);
    settextstyle(35, 17, "������Բ����");
    fillrectangle(btn->x, btn->y, btn->x + btn->width, btn->y + btn->height);
    outtextxy(btn->x + 37.5, btn->y + 20, btn->text);
}

// �ж�����Ƿ����˰�ť
bool IsButtonClicked(Button* btn, MOUSEMSG msg) {
    return (msg.x >= btn->x && msg.x <= btn->x + btn->width &&
        msg.y >= btn->y && msg.y <= btn->y + btn->height && msg.uMsg == WM_LBUTTONDOWN);
}

//��ʼ����������
void text_init()
{
    settextstyle(35, 17, "������Բ����");
    settextcolor(RGB(115, 43, 245));
    setbkcolor(WHITE);
}

//���ɿ�������
void text_print(const char* text) {
    outtextxy(320, 80, "                                      ");
    outtextxy(320, 80, text);
}

//���ƽ���
void menu_print()
{
    int x, y;
    IMAGE QG;
    loadimage(&QG, "./res/QG.png", 140, 140);

    setcolor(RGB(115, 43, 245));
    setfillcolor(RGB(115, 43, 245));
    fillrectangle(0, 0, 150, 600);
    fillrectangle(175, 25, 975, 175);
    for (x = 212.5, y = 237.5; y < 600; y += 100)
        fillcircle(x, y, 37.5);
    for (x = 512.5, y = 237.5; y < 600; y += 100)
        fillcircle(x, y, 37.5);
    for (x = 637.5, y = 237.5; y < 600; y += 100)
        fillcircle(x, y, 37.5);
    for (x = 937.5, y = 237.5; y < 600; y += 100)
        fillcircle(x, y, 37.5);

    setcolor(WHITE);
    setfillcolor(WHITE);
    fillrectangle(180, 30, 970, 170);
    for (x = 212.5, y = 237.5; y < 600; y += 100)
        fillcircle(x, y, 25);
    for (x = 637.5, y = 237.5; y < 600; y += 100)
        fillcircle(x, y, 25);

    putimage(180, 30, &QG);
}

// ����һ���ڵ㣬(x,y)Ϊ�ڵ��������꣬valueΪ�ڵ�ֵ
void drawNode(int x, int y, int value)
{
    // ����Բ��
    setfillcolor(MAIN_COLOR);
    setlinecolor(WHITE);
    fillcircle(x, y, RADIUS);

    // ���ƽڵ�ֵ
    char str[10];
    sprintf(str, "%d", value);
    settextcolor(WHITE);
    setbkmode(TRANSPARENT);
    settextstyle(20, 0, "Consolas");
    outtextxy(x - textwidth(str) / 2, y - textheight(str) / 2, str);
}

// ����BST�����нڵ�
void drawBST(NodePtr rootNode, int x, int y, int offset)
{
    if (rootNode == NULL)
        return;

    // ���Ƹ��ڵ�
    drawNode(x, y, rootNode->value);

    setcolor(MAIN_COLOR);
    // ����������
    if (rootNode->left)
    {
        int dx = x - RADIUS * 2 - offset;
        int dy = y + 4 * RADIUS;
        line(x, y, dx, dy);
        drawBST(rootNode->left, dx, dy, offset/2);
    }

    // ����������
    if (rootNode->right)
    {
        int dx = x + RADIUS * 2 + offset;
        int dy = y + 4 * RADIUS;
        line(x, y, dx, dy);
        drawBST(rootNode->right, dx, dy, offset/2);
    }
}

//��ʾ���Ľṹ
void showBST(BinarySortTreePtr BST)
{
    closegraph();
    initgraph(WINDOW_WIDTH, WINDOW_HEIGHT);
    setbkcolor(WHITE);
    cleardevice();
    settextcolor(MAIN_COLOR);
    settextstyle(20, 0, "Consolas");
    outtextxy(10, 10, "��Esc����");

    // �������Ľṹ
    drawBST(BST->root, WINDOW_WIDTH / 2, 100,100);
    FlushBatchDraw();

    // �ȴ��رմ���
    _getch();

    closegraph();
    initgraph(1000, 600);
    setbkcolor(WHITE);
    cleardevice();
}

//�����ӡ
void menu()
{
    BinarySortTreePtr BST = (BinarySortTreePtr)malloc(sizeof(BinarySortTree));

    char str[20], temp[20];
    int data;

    int flag = 0;
    int page = 1, print = 0;

    //�����ʼ��
    initgraph(1000, 600);
    setbkcolor(WHITE);
    cleardevice();

    //��ť��ʼ��
    Button initBtn = { 212.5, 199, 300, 76, "��ʼ��������", RGB(115, 43, 245) };
    Button emptyBtn = { 637.5, 199, 300, 76, "����ڵ�", RGB(115, 43, 245) };
    Button topBtn = { 212.5, 299, 300, 76, "ɾ���ڵ�", RGB(115, 43, 245) };
    Button clearBtn = { 637.5, 299, 300, 76, "�����ڵ�", RGB(115, 43, 245) };
    Button destroyBtn = { 212.5, 399, 300, 76, "����ǵݹ�+1", RGB(115, 43, 245) };
    Button lengthBtn = { 637.5, 399, 300, 76, "����ݹ�+1", RGB(115, 43, 245) };
    Button pushBtn = { 212.5, 499, 300, 76, "��ʾ���ṹ", RGB(115, 43, 245) };
    Button popBtn = { 637.5, 499, 300, 76, "��һҳ", RGB(115, 43, 245) };
    Button aBtn = { 212.5, 199, 300, 76, "����ǵݹ�+1", RGB(115, 43, 245) };
    Button bBtn = { 637.5, 199, 300, 76, "����ݹ�+1", RGB(115, 43, 245) };
    Button cBtn = { 212.5, 299, 300, 76, "����ǵݹ�+1", RGB(115, 43, 245) };
    Button dBtn = { 637.5, 299, 300, 76, "����ݹ�+1", RGB(115, 43, 245) };
    Button eBtn = { 212.5, 399, 300, 76, "��ηǵݹ�+1", RGB(115, 43, 245) };
    Button fBtn = { 637.5, 399, 300, 76, "", RGB(115, 43, 245) };
    Button gBtn = { 212.5, 499, 300, 76, "��ʾ���ṹ", RGB(115, 43, 245) };
    Button hBtn = { 637.5, 499, 300, 76, "��һҳ", RGB(115, 43, 245) };

    BeginBatchDraw();

    while (1) {
        if (page == 1 && print == 0) {
            //��ť����
            DrawButton(&initBtn);
            DrawButton(&emptyBtn);
            DrawButton(&topBtn);
            DrawButton(&clearBtn);
            DrawButton(&destroyBtn);
            DrawButton(&lengthBtn);
            DrawButton(&pushBtn);
            DrawButton(&popBtn);

            //ͼ�λ���
            menu_print();
            print = 1;
        }
        else if (page == 2 && print == 0) {
            //��ť����
            DrawButton(&aBtn);
            DrawButton(&bBtn);
            DrawButton(&cBtn);
            DrawButton(&dBtn);
            DrawButton(&eBtn);
            DrawButton(&fBtn);
            DrawButton(&gBtn);
            DrawButton(&hBtn);

            //ͼ�λ���
            menu_print();
            print = 1;
        }

        //��ʼ�������ı���ʽ
        text_init();

        // ��������¼�
        if (MouseHit()) {
            MOUSEMSG msg = GetMouseMsg();
            // �ж�����Ƿ����˰�ť
            if (IsButtonClicked(&initBtn, msg)) {
                if (page == 1)
                {
                    if (BST_init(BST)) {
                        text_print("��ʼ���ɹ���");
                        flag = 1;
                    }
                    else
                        text_print("��ʼ��ʧ�ܣ�");
                }
                else if (page == 2)
                {
                    if (!flag) {
                        text_print("���ȳ�ʼ����");
                        continue;
                    }
                    if (BST_inorderI(BST, NodeAdd))
                        text_print("ִ�гɹ���");
                    else
                        text_print("ִ��ʧ�ܣ�");
                }
            }
            else if (IsButtonClicked(&emptyBtn, msg)) {
                if (page == 1)
                {
                    if (!flag) {
                        text_print("���ȳ�ʼ����");
                        continue;
                    }
                    InputBox(str, 10, "���������������", "�����½ڵ�");
                    sprintf(temp, "%d", atoi(str));
                    if (strcmp(str, temp)) {
                        text_print("�������ݴ���");
                        continue;
                    }
                    if (BST_insert(BST, atoi(str)))
                        text_print("����ɹ���");
                    else
                    {
                        text_print("�����Ѵ��ڣ�");
                        continue;
                    }
                }
                else if (page == 2)
                {
                    if (!flag) {
                        text_print("���ȳ�ʼ����");
                        continue;
                    }

                    if (BST_inorderR(BST, NodeAdd))
                        text_print("ִ�гɹ���");
                    else
                        text_print("ִ��ʧ�ܣ�");
                }
            }
            else if (IsButtonClicked(&topBtn, msg)) {
                if (page == 1)
                {
                    if (!flag) {
                        text_print("���ȳ�ʼ����");
                        continue;
                    }
                    InputBox(str, 10, "����Ҫɾ��������", "ɾ���ڵ�");
                    sprintf(temp, "%d", atoi(str));
                    if (strcmp(str, temp))
                    {
                        text_print("�������ݴ���");
                        continue;
                    }
                    if (BST_delete(BST, atoi(str)))
                        text_print("ɾ���ɹ���");
                    else
                    {
                        text_print("���ݲ����ڣ�");
                        continue;
                    }
                }
                else if (page == 2)
                {
                    if (!flag) {
                        text_print("���ȳ�ʼ����");
                        continue;
                    }

                    if (BST_postorderI(BST, NodeAdd))
                        text_print("ִ�гɹ���");
                    else
                        text_print("ִ��ʧ�ܣ�");
                }              
            }
            else if (IsButtonClicked(&clearBtn, msg)) {
                if (page == 1)
                {
                    if (!flag) {
                        text_print("���ȳ�ʼ����");
                        continue;
                    }

                    InputBox(str, 10, "����Ҫ����������", "�����ڵ�");
                    sprintf(temp, "%d", atoi(str));
                    if (strcmp(str, temp))
                    {
                        text_print("�������ݴ���");
                        continue;
                    }
                    if (BST_search(BST, atoi(str)))
                        text_print("�ڵ���ڣ�");
                    else
                    {
                        text_print("�ڵ㲻���ڣ�");
                        continue;
                    }
                }
                else if (page == 2)
                {
                    if (!flag) {
                        text_print("���ȳ�ʼ����");
                        continue;
                    }

                    if (BST_postorderR(BST, NodeAdd))
                        text_print("ִ�гɹ���");
                    else
                        text_print("ִ��ʧ�ܣ�");
                }
            }
            else if (IsButtonClicked(&destroyBtn, msg)) {
                if (page == 1)
                {
                    if (!flag) {
                        text_print("���ȳ�ʼ����");
                        continue;
                    }

                    if (BST_preorderI(BST, NodeAdd))
                        text_print("ִ�гɹ���");
                    else
                        text_print("ִ��ʧ�ܣ�");
                }
                else if (page == 2)
                {
                    if (!flag) {
                        text_print("���ȳ�ʼ����");
                        continue;
                    }

                    if (BST_levelOrder(BST, NodeAdd))
                        text_print("ִ�гɹ���");
                    else
                        text_print("ִ��ʧ�ܣ�");
                }
            }
            else if (IsButtonClicked(&lengthBtn, msg)) {
                if (page == 1)
                {
                    if (!flag) {
                        text_print("���ȳ�ʼ����");
                        continue;
                    }

                    if (BST_preorderR(BST, NodeAdd))
                        text_print("ִ�гɹ���");
                    else
                        text_print("ִ��ʧ�ܣ�");
                }
                else if (page == 2)
                {
                    text_print("ɶ��ľ��");
                }
            }
            else if (IsButtonClicked(&pushBtn, msg)) {
                if (!flag) {
                    text_print("���ȳ�ʼ����");
                    continue;
                }

                showBST(BST);
                print = 0;
                FlushBatchDraw();
            }
            else if (IsButtonClicked(&popBtn, msg)) {
                if (page == 1) {
                    page = 2;
                    print = 0;
                }
                else if (page == 2) {
                    page = 1;
                    print = 0;
                }
            }
        }
        FlushBatchDraw();
    }

    EndBatchDraw();
    closegraph();
}
