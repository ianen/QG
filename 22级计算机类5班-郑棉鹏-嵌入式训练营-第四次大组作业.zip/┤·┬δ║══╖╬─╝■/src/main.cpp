#include "menu.h"

int main()
{
    menu();
    return 0;
}