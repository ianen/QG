/***************************************************************************************
 *	File Name				:	linkedList.h
 *	CopyRight				:	2020 QG Studio
 *	SYSTEM					:   win10
 *	Create Data				:	2020.3.28
 *
 *
 *--------------------------------Revision History--------------------------------------
 *	No	version		Data			Revised By			Item			Description
 *
 *
 ***************************************************************************************/

 /**************************************************************
*	Multi-Include-Prevent Section
**************************************************************/
#ifndef LINKEDLIST_H_INCLUDED
#define LINKEDLIST_H_INCLUDED

/**************************************************************
*	Macro Define Section
**************************************************************/

#define OVERFLOW -1

/**************************************************************
*	Struct Define Section
**************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// define element type
typedef char *ElemType;

// define struct of linked list
typedef struct LNode {
	ElemType data;
  	struct LNode *next;
} LNode, *LinkedList;

// define Status
typedef enum Status {
	ERROR,	 
	SUCCESS
} Status;


/**************************************************************
*	Prototype Declare Section
**************************************************************/

/**
 *  @name        : Status InitList(LinkList *L);
 *	@description : initialize an empty linked list with only the head node without value
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status InitList(LinkedList *L);

/**
 *  @name        : void DestroyList(LinkedList *L)
 *	@description : destroy a linked list, free all the nodes
 *	@param		 : L(the head node)
 *	@return		 : None
 *  @notice      : None
 */
void DestroyList(LinkedList *L);

/**

@name : Status InsertList(LinkedList L, int i, ElemType e);
@description : �ڵ������ĵ�i��λ�ò���Ԫ��e
@param : L ����ͷ�ڵ�ָ�� ,i ����λ��,e ����Ԫ��ֵ
@return : Status
@notice : ���i�����������ȣ�����ERROR
*/
Status InsertList(LinkedList L, int i, ElemType e);

/**
@name : Status DeleteList(LinkedList L, int i)
@description : delete the ith element in the linked list
@param : L(the head node), i(position of the element to be deleted)
@return : Status
@notice : None
*/
Status DeleteList(LinkedList L, int i);

/**
@name : Status TraverseList(LinkedList L, void (*visit)(ElemType e))
@description : ������������ÿ���ڵ���ú���ָ��visit
@param : L (����ͷָ��)��visit (����ָ�룬���ڷ��ʽڵ�Ԫ��)
@return : Status
@notice : None
*/
Status TraverseList(LinkedList L, void (*visit)(ElemType e));

/**
 *  @name        : Status SearchList(LinkedList L, ElemType e)
 *	@description : find the first node in the linked list according to e
 *	@param		 : L(the head node), e
 *	@return		 : Status
 *  @notice      : None
 */
Status SearchList(LinkedList L, ElemType e);

/**
 *  @name        : Status ReverseList(LinkedList *L)
 *	@description : reverse the linked list
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status ReverseList(LinkedList *L);

/**
@name : Status LoopList(LinkedList *L)
@description : �����������ѭ������
@param : L (������ͷָ��)
@return : Status
@notice : None
*/
Status LoopList(LinkedList* L);

/**
 *  @name        : Status IsLoopList(LinkedList L)
 *	@description : judge whether the linked list is looped
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status IsLoopList(LinkedList *L);

/**
 *  @name        : LNode* ReverseEvenList(LinkedList *L)
 *	@description : reverse the nodes which value is an even number in the linked list, input: 1 -> 2 -> 3 -> 4  output: 2 -> 1 -> 4 -> 3
 *	@param		 : L(the head node)
 *	@return		 : LNode(the new head node)
 *  @notice      : choose to finish
 */
LNode* ReverseEvenList(LinkedList *L);

/**
 *  @name        : LNode* FindMidNode(LinkedList *L)
 *	@description : find the middle node in the linked list
 *	@param		 : L(the head node)
 *	@return		 : LNode
 *  @notice      : choose to finish
 */
LNode* FindMidNode(LinkedList *L);

/**

@name : void PrintNode(ElemType data)
@description : print the data of a single node
@param : data(the data of the node to be printed)
@return : None
@notice : None
*/
void PrintNode(ElemType data);

/**

@name : Status EmptyJudge(LinkedList* L)
@description : judge whether the linked list is empty or not
@param : L(the head node)
@return : Status(ERROR: not empty; SUCCESS: empty)
@notice : None
*/
Status EmptyJudge(LinkedList* L);

 /**************************************************************
*	End-Multi-Include-Prevent Section
**************************************************************/


#endif
