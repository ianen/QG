#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

int menu()
{
	int choice;
	printf("************************************************************\n");
	printf("* ������ADT������������                                    *\n");
	printf("*                                                          *\n");
	printf("* [1]��ʼ������                                            *\n");
	printf("*                                                          *\n");
	printf("* [2]��ʾ����                                              *\n");
	printf("*                                                          *\n");
	printf("* [3]��������                                              *\n");
	printf("*                                                          *\n");
	printf("* [4]������ѯ                                              *\n");
	printf("*                                                          *\n");
	printf("* [5]�����½ڵ�                                            *\n");
	printf("*                                                          *\n");
	printf("* [6]ɾ���ڵ�                                              *\n");
	printf("*                                                          *\n");
	printf("* [7]������ת                                              *\n");
	printf("*                                                          *\n");
	printf("* [8]��ż�Ի�                                              *\n");
	printf("*                                                          *\n");
	printf("* [9]����ѭ������                                          *\n");
	printf("*                                                          *\n");
	printf("* [10]�ж�ѭ������                                         *\n");
	printf("*                                                          *\n");
	printf("* [11]��ѯ�е�                                             *\n");
	printf("*                                                          *\n");
	printf("* [12]�˳�ϵͳ                                             *\n");
	printf("*                                                          *\n");
	printf("************************************************************\n");
	printf("����������ִ�еĹ��ܣ�");
	scanf("%d", &choice);
	while (getchar() != '\n');
	system("CLS");
	return choice;
}