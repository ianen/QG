#ifndef __MENU_H__
#define __MENU_H__

int menu();

#endif 