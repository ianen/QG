#include "Menu.h"

int main() {
	menu();
}